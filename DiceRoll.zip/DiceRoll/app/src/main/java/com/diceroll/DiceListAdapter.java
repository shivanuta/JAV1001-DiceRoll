package com.diceroll;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Collections;


/*
* Adapter for setting list
* */
public class DiceListAdapter extends RecyclerView.Adapter<DiceListAdapter.ViewHolder> {
    private ArrayList<String> diceArrayList;

    public void setDiceArrayList(ArrayList<String> diceArrayList) {
        this.diceArrayList = (ArrayList<String>) diceArrayList.clone();
        Collections.reverse(this.diceArrayList);
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.row_dice, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    /*
    * Binds data to adapter
    * */
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final String myListData = diceArrayList.get(position);
        holder.tvDiceText.setText(myListData);
    }


    @Override
    public int getItemCount() {

        return diceArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvDiceText;
        public RelativeLayout rv;

        public ViewHolder(View itemView) {
            super(itemView);
            this.tvDiceText = (TextView) itemView.findViewById(R.id.tvDiceText);
            rv = (RelativeLayout) itemView.findViewById(R.id.rv);
        }
    }
}