package com.diceroll;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity
        implements AdapterView.OnItemSelectedListener, View.OnClickListener {

    String[] diceSidesList = {"4", "6",
            "8", "10",
            "12", "20", "custom"};
    Spinner diceSidesSpin;
    private int selectedSidePos = 0;

    public static final String APP_PREFERENCES = "AppPrefs";
    public static final String DICE_LIST_KEY = "dice_list_key";
    SharedPreferences sharedPref;
    private ArrayList<String> savedDiceList;

    DiceListAdapter diceListAdapter;
    private RecyclerView rvDiceValues;

    private Button btnDiceRollOnce, btnDiceRollTwice;
    private LinearLayout customLay;
    private EditText etCustom;
    private TextView tvRolledDiceScore;
    private Boolean isCustomSelected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPref = getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE);
        savedDiceList = getStoredDiceList();

        diceSidesSpin = findViewById(R.id.spnrSides);
        diceSidesSpin.setOnItemSelectedListener(this);
        ArrayAdapter ad
                = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                diceSidesList);
        ad.setDropDownViewResource(
                android.R.layout
                        .simple_spinner_dropdown_item);
        diceSidesSpin.setAdapter(ad);

        rvDiceValues = findViewById(R.id.rvDiceValues);
        diceListAdapter = new DiceListAdapter();
        diceListAdapter.setDiceArrayList(savedDiceList);
        rvDiceValues.setHasFixedSize(true);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3);
        rvDiceValues.setLayoutManager(gridLayoutManager);
        rvDiceValues.setAdapter(diceListAdapter);

        tvRolledDiceScore = findViewById(R.id.tvRolledDiceScore);
        etCustom = findViewById(R.id.etCustomInput);
        customLay = findViewById(R.id.tvCustomInputLay);
        btnDiceRollOnce = findViewById(R.id.btnDiceRoll);
        btnDiceRollTwice = findViewById(R.id.btnDiceRollTwice);

        btnDiceRollOnce.setOnClickListener(this);
        btnDiceRollTwice.setOnClickListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        selectedSidePos = position;

        if (selectedSidePos == 6) {
            isCustomSelected = true;
            customLay.setVisibility(View.VISIBLE);
        } else {
            isCustomSelected = false;
            customLay.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    /*
     * Retreiving stored dice values from Shared Preferences
     * */
    public ArrayList<String> getStoredDiceList() {
        ArrayList<String> diceList = new ArrayList<>();
        String serializedObject = sharedPref.getString(DICE_LIST_KEY, null);
        if (serializedObject != null) {
            Gson gson = new Gson();
            Type type = new TypeToken<List<String>>() {
            }.getType();
            diceList = gson.fromJson(serializedObject, type);
        }
        return diceList;
    }

    /*
     * Updated the dice values in recylerview
     * And calls setDiceList function to store the recent value in Shared Preferences
     * */
    private void rollDice(String numberOfSides) {
        tvRolledDiceScore.setVisibility(View.VISIBLE);
        int rolledDiceValue = roll(Integer.parseInt(numberOfSides));
        tvRolledDiceScore.setText(String.valueOf(rolledDiceValue));

        savedDiceList.add(String.valueOf(rolledDiceValue));
        setDiceList(DICE_LIST_KEY, savedDiceList);

        diceListAdapter.setDiceArrayList(savedDiceList);
    }

    /*
     * Generate Random number based on sides
     * */
    public int roll(int maxSides) {
        Random random = new Random();
        return random.nextInt(maxSides) + 1;
    }

    /*
     * Converts list to Gson for Saving
     * */
    public void setDiceList(String key, List<String> list) {
        Gson gson = new Gson();
        String json = gson.toJson(list);
        saveItem(key, json);
    }

    /*
     * Saves list using shared pref
     * */
    public void saveItem(String key, String value) {
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(key, value);
        editor.commit();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnDiceRoll:
                clickDiceRoll();
                break;
            case R.id.btnDiceRollTwice: {
                clickDiceRoll();
                Runnable r = new Runnable() {
                    @Override
                    public void run() {
                        clickDiceRoll();
                    }
                };

                Handler h = new Handler();
                h.postDelayed(r, 2000);
            }
        }

    }

    /*  on click rollButton this method executes*/
    public void clickDiceRoll() {
        tvRolledDiceScore.setVisibility(View.GONE);
        if (isCustomSelected) {
            if (!etCustom.getText().toString().isEmpty())
                rollDice(etCustom.getText().toString().trim());
            else
                Toast.makeText(this, "Please enter Dice Side value", Toast.LENGTH_LONG).show();
        } else {
            rollDice(diceSidesList[selectedSidePos]);
        }
    }
}